# IPhoneMotionToOsc
Publishes IPhone Motion data using CoreMotion via OSC
