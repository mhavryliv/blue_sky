#pragma once
#include "../../JuceLibraryCode/JuceHeader.h"

class NetworkUtils
{
public:
	static IPAddress getCurrentIPAddress(); 
};
